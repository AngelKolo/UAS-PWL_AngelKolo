</div> <!-- end container -->
<footer class="bg-light text-center text-lg-start mt-5">
  <div class="text-center p-3 bg-secondary text-white">
    © 2025 Komunitas Pecinta Coding. All rights reserved.<br>
    Dibuat oleh : A11.2021.13212 - Angelica Widyastuti Kolo
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
